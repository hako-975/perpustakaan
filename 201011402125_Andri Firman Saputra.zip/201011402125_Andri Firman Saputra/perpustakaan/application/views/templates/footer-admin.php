		</div>
		<div class="text-center flashdata" data-flashdata="<?= $this->session->flashdata('message'); ?>"></div>
		<div class="text-center flashdata-success" data-flashdata="<?= $this->session->flashdata('message-success'); ?>"></div>
		<div class="text-center flashdata-failed" data-flashdata="<?= $this->session->flashdata('message-failed'); ?>"></div>
		<!-- ./Sweet Alert 2 -->

		<!-- /.content-wrapper -->
		<footer class="main-footer">
			<strong>Hak Cipta &copy; 2024 Perpustakaan.</strong>
			<div class="float-right d-none d-sm-inline-block">
				<b>Versi</b> 1.0.0
			</div>
		</footer>
	</div>
</body>
</html>