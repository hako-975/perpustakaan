<!-- jQuery -->
<script src="<?= base_url('assets/vendor/jquery/jquery-3.6.0.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/jquery-easing/jquery.easing.min.js'); ?>"></script>
<!-- popper -->
<script src="<?= base_url('assets/vendor/popper/popper.min.js'); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?= base_url('assets/vendor/bootstrap/js/bootstrap.min.js'); ?>"></script>
<!-- overlayScrollbars -->
<script src="<?= base_url('assets/vendor/overlayScrollbars/js/jquery.overlayScrollbars.min.js'); ?>"></script>
<!-- datatables -->
<script src="<?= base_url('assets/vendor/datatables/js/jquery.dataTables.min.js'); ?>"></script>
<script src="<?= base_url('assets/vendor/datatables/js/dataTables.bootstrap4.min.js'); ?>"></script>
<!-- fancybox -->
<script src="<?= base_url('assets/vendor/fancybox/js/jquery.fancybox.min.js'); ?>"></script>
<!-- sweetalert2 -->
<script src="<?= base_url('assets/vendor/sweetalert2/sweetalert2.all.min.js'); ?>"></script>
<!-- AdminLTE App -->
<script src="<?= base_url('assets/vendor/adminlte/js/adminlte.min.js'); ?>"></script>
<!-- Chart JS -->
<script src="<?= base_url('assets/vendor/chart/chart.min.js'); ?>"></script>

<!-- config -->
<script src="<?= base_url('assets/js/jquery-easing-config.js'); ?>"></script>
<script src="<?= base_url('assets/js/datatables-config.js'); ?>"></script>
<script src="<?= base_url('assets/js/fancybox-config.js'); ?>"></script>
<script src="<?= base_url('assets/js/sweetalert2-config.js'); ?>"></script>
<script src="<?= base_url('assets/js/popover-config.js'); ?>"></script>
<script src="<?= base_url('assets/js/toast-config.js'); ?>"></script>
