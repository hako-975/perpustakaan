$(document).ready(function() {
  $(".enlarge").fancybox();
});
